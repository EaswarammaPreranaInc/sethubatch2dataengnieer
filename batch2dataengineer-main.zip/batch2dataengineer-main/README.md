# batch2dataengineer
assignments
