r=range(10 , 17 , 3)
a,b,c = r
print(a,b,c)
r=range(3)
#x,y=r
#p,q,r,s=r
#a,b,c=*r
m=r
print(id(r))
print(id(m))